# v6：正常HTTP header情境與Accept語意修正

train702（每類234），test150、Sylius validation150、challenge96原CSV凍結，共1098筆。原594筆train保留，僅新增36組三類配對108筆；相同profile同時給normal／SQLi／XSS，不把客戶端與類別綁定。
新增Accept、Accept-Encoding、Connection、User-Agent、Host是HTTP傳輸header，保留所有原有API文件欄位及非覆寫業務headers；不捏造新API參數。路徑、query、本文與攻擊原文不變，沒有使用Medusa樣本訓練。
特徵v6仍2402維，只修正合法Accept媒體型別萬用字元不算SQL註解；其餘header內容與所有raw ngram仍分析。不刪header、不正規化原文、不調分類門檻。舊v5模型不能混用新特徵。
所有資料仍offline候選、HTTP=0。保留題已被檢視，只供探索性比較；真實Medusa購物業務流程尚未完成驗收。正常長路徑缺口、條件商品與歷史ID限制仍保留。

```json
{
  "evaluation_protocol": "document-v4-skeleton-disjoint",
  "main_ratio": "702:150:150; holdouts frozen",
  "extra_challenge_is_not_part_of_ratio": true,
  "splits": {
    "train": {
      "rows": 702,
      "labels": {
        "normal": 234,
        "sqli": 234,
        "xss": 234
      },
      "platforms": {
        "bagisto": 246,
        "shopware": 456
      }
    },
    "test": {
      "rows": 150,
      "labels": {
        "normal": 50,
        "sqli": 50,
        "xss": 50
      },
      "platforms": {
        "bagisto": 84,
        "shopware": 66
      }
    },
    "validation": {
      "rows": 150,
      "labels": {
        "normal": 50,
        "sqli": 50,
        "xss": 50
      },
      "platforms": {
        "sylius": 150
      }
    },
    "challenge": {
      "rows": 96,
      "labels": {
        "normal": 32,
        "sqli": 32,
        "xss": 32
      },
      "platforms": {
        "bagisto": 36,
        "shopware": 60
      }
    }
  },
  "parameter_document_sha256": {
    "sentinel/analysis/selected-api-contracts/bagisto/API_parameters.md": "783a8da3b6a93ae2fb0215260373e7e541998a642e16af5a6acde10a6a44758d",
    "sentinel/analysis/selected-api-contracts/shopware/API_parameters.md": "af6f3cadbf1e229c7db01bf12d7e43612e95bf74ef0381017bd2fdc42ca520f5",
    "sentinel/analysis/selected-api-contracts/sylius/API_parameters.md": "09684354ddaec52ec4f77c0a0bbcc5d1847ed6cb0f697e8df2ba2dac05dd2179"
  },
  "document_fields": 620,
  "api_operations": 62,
  "external_source": {
    "commit": "926670a710283f87c05b554680facf3f9530548c",
    "url": "https://raw.githubusercontent.com/Morzeux/HttpParamsDataset/926670a710283f87c05b554680facf3f9530548c/payload_full.csv",
    "sha256": "a4e62ba13435ad3dd583c5790db2175629020fc41c56e1b26baa02a9ae45f03d",
    "excluded_previous_external_values": 17,
    "selection": "seeded 24 per class; <=256 chars; no controls; no score-based filtering"
  },
  "http_executed": 0,
  "medusa_included": false,
  "source_generators_sha256": {
    "build_transport_v6.py": "1726b199627ce29d0aa8e6fe6c37d2b6b46fb1719ced3651ae22544f5f8b9fd1",
    "build_train_v5.py": "045cabe9e637a42eff03238ac80b3aac9fc449f0e8e47ba64327626f0461ceaa"
  },
  "baseline_csv_sha256": {
    "train": "b49d0291d725b5cd9ef20bf0fec4b1e62b5f24ca4041dd8adfbc8b9ae0bb8643",
    "test": "f94a79a4da2de0a652d12800f4c6a0846f27f3c85921bd304cd6d98844e81788",
    "validation": "6d8320a20065bded2de497cfe73c022a6550a2f5356068766a61f4f2580cf3c8",
    "challenge": "695514773ce22200c99945e8fd27b2638ff6df1ebe3ccdcb9c24dc7d6cab6376"
  },
  "skeleton_rule_version": 1,
  "skeleton_parser": {
    "id": "cpython-3.11.3-htmlparser-frozen-v1",
    "sha256": {
      "_skeleton_html_v1.py": "d50e7f0424cc76e88d6233a83654b2d456576a1980a8363b93955e9545763a1e",
      "_skeleton_markupbase_v1.py": "e7ec858cf543823191d8535e2f45945aa522bcfda7ce521a5fde04d618ee0e0a",
      "SKELETON-PYTHON-LICENSE.txt": "616fa565945eca2f0e0a5440b3973fed7d5291622b90849212077fe68e27dcb0"
    }
  },
  "skeleton_catalog_sha256": "ab176a26caeca72e5f8ea1c1cc0c2b0988a16e2cdd64a21a2552ab52ad7ced67",
  "skeleton_groups": {
    "train": {
      "xss": 35,
      "sqli": 31
    },
    "test": {
      "xss": 4,
      "sqli": 2
    },
    "validation": {
      "sqli": 20,
      "xss": 23
    },
    "challenge": {
      "xss": 8,
      "sqli": 4
    }
  },
  "excluded_local_overlaps": 0,
  "baseline": "small-api-v3 unchanged; raw-template/seen-family comparison only",
  "skeleton_source_sha256": "c46de4972ef09b21ec18342d0208b5429a23298d9db005d8fd7f6386104533c8",
  "dataset_revision": "v6-transport-augmentation",
  "frozen_holdout_sha256": {
    "test": "f94a79a4da2de0a652d12800f4c6a0846f27f3c85921bd304cd6d98844e81788",
    "validation": "6d8320a20065bded2de497cfe73c022a6550a2f5356068766a61f4f2580cf3c8",
    "challenge": "695514773ce22200c99945e8fd27b2638ff6df1ebe3ccdcb9c24dc7d6cab6376"
  },
  "augmentation": {
    "triples": 48,
    "rows": 144,
    "per_class": 48,
    "platforms": {
      "shopware": 90,
      "bagisto": 54
    },
    "new_payloads_per_class": {
      "sqli": 24,
      "xss": 24
    },
    "decisions": {
      "new_training_skeleton": 48
    },
    "source": "locally curated SQL/JS fragments and documented normal contrast; not new external corpus",
    "evaluation_already_inspected": true,
    "normal_long_path_gap": "no fabricated routes/IDs; still unresolved"
  },
  "required_feature_version": 6,
  "transport_augmentation": {
    "triples": 36,
    "rows": 108,
    "per_class": 36,
    "profiles": [
      {
        "name": "json_client",
        "headers": {
          "Accept": "application/json",
          "Accept-Encoding": "gzip, deflate",
          "Connection": "keep-alive",
          "User-Agent": "msdss-client/1.0",
          "Host": "localhost"
        }
      },
      {
        "name": "httpx_any",
        "headers": {
          "Accept": "*/*",
          "Accept-Encoding": "gzip, deflate",
          "Connection": "keep-alive",
          "User-Agent": "python-httpx/0.28.1",
          "Host": "localhost"
        }
      },
      {
        "name": "application_range",
        "headers": {
          "Accept": "application/*;q=0.9,application/json",
          "Accept-Encoding": "gzip, deflate, br",
          "Connection": "keep-alive",
          "User-Agent": "Mozilla/5.0",
          "Host": "localhost"
        }
      },
      {
        "name": "browser_ranges",
        "headers": {
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Encoding": "gzip, deflate, br",
          "Connection": "keep-alive",
          "User-Agent": "Mozilla/5.0",
          "Host": "localhost"
        }
      }
    ],
    "business_fields_changed": false,
    "all_from_train": true
  }
}
```
